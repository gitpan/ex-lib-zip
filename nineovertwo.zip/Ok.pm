package Ok;
sub Ok {
  print "ok @_\n";
}
1;
