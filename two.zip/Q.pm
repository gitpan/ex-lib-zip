#!perl -w
use strict;
package Q;
sub qsub {
  "This is Q";
}
1;
